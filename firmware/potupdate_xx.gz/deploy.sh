#!/bin/bash

LWDIR="/LiveWellLab"
STAGEDIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

echo 'Stopping services'
service pi_manager stop
service bled stop
pkill -f sense
pkill -f pump

cd $STAGEDIR
cp etc_init/*.conf /etc/init/
cp bin/* $LWDIR

cd $LWDIR

if [[ ! -f config.json ]]; then
	DEVICE_ID=$1

	if [[ -z "$DEVICE_ID" ]]; then
		echo 'No device ID provided'
		echo 'Syntax:'
		echo '     $ [shell_script] <DeviceID>'
		exit 1
	fi

	ACCESS_CODE=$(./bled pingen $DEVICE_ID)
	cat config_template.json | python config_writer.pyc $DEVICE_ID $ACCESS_CODE > config.json

	echo "Set up new config with device with ID: $DEVICE_ID  Access Code: $ACCESS_CODE"
else
	echo "Used existing config"
fi

echo 'Initializing/reseting data store'
python pi_data_manager.pyc origin

echo 'Content of data store (should be empty):'
python pi_data_manager.pyc dump

echo 'Starting services'
service auto_update start
service pi_manager start
service bled start
