#!/bin/bash

LWDIR="/LiveWellLab"
STAGEDIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

service pi_manager stop
service bled stop
pkill -f sense
pkill -f pump

cd $STAGEDIR
cp etc_init/*.conf /etc/init/
cp bin/* $LWDIR

cd $LWDIR

echo 'Initializing/reseting data store'
python pi_data_manager.pyc origin
echo 'Content of data store (should be empty):'
python pi_data_manager.pyc dump

service pi_manager start
service bled start
service auto_update start

echo "Deployed successfully"
